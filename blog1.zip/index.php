<?php
include 'koneksi.php';
$posts = mysqli_query($conn, "SELECT * FROM post");
?>

<!DOCTYPE html>
<head>
	<title>Blog Post</title>
</head>
<body>
	<?php
	while($row = mysqli_fetch_array($posts)) {
		echo "<a href='post.php?id={$row['id']}'><h2>{$row['judul']}</h2></a>";
		echo "<small>Tanggal {$row['tanggal']}</small>";
		echo "<hr>";	
	}
	?>
</body>
</html>
