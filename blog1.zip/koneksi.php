<?php

$host = "localhost";
$user = "adminblog";
$pass = "eOcfOtRQHtfsu590";
$db   = "blog";

$conn = mysqli_connect($host, $user, $pass);
mysqli_select_db($conn, $db);
