<?php
include 'koneksi.php';
$id = intval($_GET['id']);
$q  = mysqli_query($conn, "SELECT * FROM post WHERE id = {$id}") or die(mysqli_error($conn));
$post = mysqli_fetch_array($q);
?>

<!DOCTYPE html>
<head>
	<title>Blog</title>
</head>
<body>
	<h2><?php echo $post['judul'] ?></h2>
	<small>Tanggal <?php echo $post['tanggal'] ?></small>	
	<?php echo $post['konten'] ?>	
</body>
</html>
