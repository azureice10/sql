<?php
session_start();
include 'koneksi.php';

$Vemail = $_POST['email'];
$Vpesan = $_POST['pass'];
$algo = "AES-128-CBC";
$key = "secretkey";
$opt = 0;
$iv = random_bytes(16);

$encrypt = openssl_encrypt($Vpesan, $algo, $key, $opt, $iv);
$decrypt = openssl_decrypt($encrypt, $algo, $key, $opt, $iv);

$insert = mysqli_query($conn, "INSERT INTO pesan (Dari,isi) 
VALUES ('{$Vemail}', '{$encrypt}')");

if ($insert) {
    echo "Pesan berhasil diinput" ."<br>";
    echo "Hasil Decrypt: ".$decrypt ;
}